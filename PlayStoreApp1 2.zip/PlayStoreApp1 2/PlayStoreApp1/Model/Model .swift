//
//  Model .swift
//  PlayStoreApp1
//
//  Created by Brahmastra on 02/01/23.
//  Copyright © 2023 Brahmastra. All rights reserved.
//

import Foundation
struct JsonModel{
    var title: String = ""
    var popularity: String = ""
    var id: String = ""
    var poster_path: String = ""
   
    
    init(){
        
    }
    init(json:JSON){
        title = json["title"].stringValue
        popularity = json["popularity"].stringValue
        poster_path = json["poster_path"].stringValue
        id = json["id"].stringValue
      
    }
}

