//
//  jsonViewController.swift
//  PlayStoreApp1
//
//  Created by Brahmastra on 04/01/23.
//  Copyright © 2023 Brahmastra. All rights reserved.
//

import UIKit


class jsonViewController: UIViewController {
    var arrData = [JsonModel]()

    override func viewDidLoad() {
        super.viewDidLoad()

        jsonPasring()
    }
    func jsonPasring(){
           let url = URL(string: "https://api.themoviedb.org/3/movie/popular?api_key=60af9fe8e3245c53ad9c4c0af82d56d6&language=en-US&page=1")
           URLSession.shared.dataTask(with: url!) { (data, response, error)
               in
               guard let data = data else { return }
               do{
                   let json = try JSON(data:data)
                   let results = json["results"]
                   for arr in results.arrayValue{
                       self.arrData.append(JsonModel(json: arr))
                   }
                   print(self.arrData)
               }catch{
                   print(error.localizedDescription)
               }
    }.resume()
       }

}
