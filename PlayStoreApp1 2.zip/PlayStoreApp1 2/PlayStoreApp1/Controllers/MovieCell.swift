//
//  MovieCell.swift
//  PlayStoreApp1
//
//  Created by Brahmastra on 03/01/23.
//  Copyright © 2023 Brahmastra. All rights reserved.
//

import UIKit

class MovieCell: UITableViewCell {

    @IBOutlet weak var mtlbl: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    override func awakeFromNib() {
        super.awakeFromNib()
    
        
        collectionView.delegate = self
        collectionView.dataSource = self
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)


    }

}
extension MovieCell : UICollectionViewDataSource,UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
       // return arrData.count
        return 10    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectioncell", for: indexPath) as? CollectionViewCell
//       cell?.titleLabel.text = arrData[indexPath.row].title
//        cell?.idLabel.text = arrData[indexPath.row].id
//    cell?.popularityLabel.text = arrData[indexPath.row].popularity
        cell?.myimg.layer.cornerRadius = 10.0
        cell?.myimg2.layer.cornerRadius = 10.0
       
        var baseurl = "https://image.tmdb.org/t/p/w200"
        
//        let poster_path = arrData[indexPath.row].poster_path
//        let joined = baseurl + poster_path
//
//        print(joined)
        
        return cell!
        
    }
    
    
}
